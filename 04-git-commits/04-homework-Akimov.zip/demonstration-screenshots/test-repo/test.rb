print 'Please type name >'
name = gets.chomp
puts "Hello #{name}."